package Utils.Collections;

public interface Observer {
    /**
     * React to changes in observable
    */
    public void update();
}

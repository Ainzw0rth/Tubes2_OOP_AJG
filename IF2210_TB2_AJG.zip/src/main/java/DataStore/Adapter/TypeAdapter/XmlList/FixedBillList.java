package DataStore.Adapter.TypeAdapter.XmlList;

import Entity.*;
import java.util.ArrayList;
import lombok.AllArgsConstructor;

@AllArgsConstructor
public class FixedBillList {
    public ArrayList<FixedBill> fixedBills;
}

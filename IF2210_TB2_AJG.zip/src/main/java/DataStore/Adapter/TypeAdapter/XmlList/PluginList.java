package DataStore.Adapter.TypeAdapter.XmlList;

import java.util.ArrayList;
import lombok.AllArgsConstructor;

@AllArgsConstructor
public class PluginList {
    public ArrayList<String> pluginPaths;
}

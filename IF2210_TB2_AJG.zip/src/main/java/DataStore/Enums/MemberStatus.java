package DataStore.Enums;

public enum MemberStatus {
    ACTIVE,
    INACTIVE,
    VIP
}
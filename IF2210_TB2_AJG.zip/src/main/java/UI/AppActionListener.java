package UI;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import org.jetbrains.annotations.*;

import Entity.Bill;

import javax.swing.*;
import java.util.*;

import UI.Page.*;

public class AppActionListener implements ActionListener {
    private List<JButton> tabCloseButtons = new ArrayList<JButton>();
    @NotNull
    private IApp app;

    public AppActionListener(IApp app) {
        this.app = app;
    }

    /**
     * Add close button for tab
     * 
     * @param button button to be added
     */
    public void addTabCloseButton(JButton button) {
        tabCloseButtons.add(button);
    }

    /**
     * Remove close button for tab
     * 
     * @param button button to be removed
     */
    public void removeTabCloseButton(int index) {
        tabCloseButtons.remove(index);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (tabCloseButtons.contains(e.getSource())) {
            /* Close tab when close button is clicked */
            int index = tabCloseButtons.indexOf(e.getSource());
            app.removeTab(index);
        } else if (e.getSource() instanceof JMenuItem) {
            /* Open a new tab when menu item is clicked */
            JMenuItem item = (JMenuItem) e.getSource();
            String title = item.getText();

            /* Action mapping */
            if (title.equals("Main Menu")) {
                // Main Menu
                app.addTab("Main Menu", new MainMenu());
            } else if (title.equals("Tambah Member")) {
                // Menu Tambah Member
                app.addTab("Tambah Member", new TambahMember());
            } else if (title.equals("Update Member")) {
                // Menu Update Member
                app.addTab("Update Member", new UpdateMember());
            } else if (title.equals("Riwayat Transaksi Member")) {
                // Menu Riwayat Transaksi Member
                app.addTab("Riwayat Transaksi Member", new HistoriTransaksi());
            } else if (title.equals("Jual Barang")) {
                Bill newBill;
                try {
                    newBill = new Bill(-1);
                    app.addTab("Jual Barang", new JualBarang(newBill));
                } catch (Exception e1) {
                }
            } else if (title.equals("Tambah Barang")) {
                app.addTab("Tambah Barang", new TambahBarang());
            } else if (title.equals("Update Barang")) {
                app.addTab("Update Barang", new UpdateBarang());
            } else if (title.equals("Laporan Penjualan")) {
                app.addTab("Laporan Penjualan", new LaporanPenjualan());
            } else if (title.equals("Plugins")) {
                app.addTab("Plugins", new PluginImport());
            } else if (title.equals("Penyimpanan Data")) {
                app.addTab("Penyimpanan Data", new PenyimpananData());
            } else {
                System.out.println("Menu tidak dikenali");
            }
        } else {
            System.out.println("Event tidak dikenali");
        }
    }
}